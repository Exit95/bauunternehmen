function e(n){return n?.length!==void 0?n:Array.from(n)}export{e};
