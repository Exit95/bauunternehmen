import{S as v,i as A,s as F,n as $,d as r,m as H,o as S,p as T,c as d,b as u,q as B,r as p,u as E,e as f,v as Q,w as _,h as g,x as j,y as q,j as x,H as C,k as y,z as L}from"../chunks/CTO0dJwd.js";import"../chunks/IHki7fMi.js";import{F as M}from"../chunks/BNhb9MVz.js";function z(w){let t,i,b=`<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Bieten Sie Festpreise?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Ja – nach Ortstermin erhalten Sie ein Festpreisangebot mit Leistungsbeschreibung und Zeitplan."
          }
        }
      ]
    }
  <\/script>`,o,l,n,h='<div class="container"><header class="text-center mb-8"><h1 class="display text-4xl mb-4">Häufige Fragen</h1> <p class="text-xl">Alles was Sie über unser Bauunternehmen wissen möchten.</p></header></div>',c,s,m;return s=new M({}),{c(){t=x("meta"),i=new C(!1),o=_(),l=y(),n=x("section"),n.innerHTML=h,c=y(),L(s.$$.fragment),this.h()},l(e){const a=E("svelte-1oh3njr",document.head);t=f(a,"META",{name:!0,content:!0}),i=Q(a,!1),o=_(),a.forEach(r),l=g(e),n=f(e,"SECTION",{class:!0,"data-svelte-h":!0}),j(n)!=="svelte-953wun"&&(n.innerHTML=h),c=g(e),q(s.$$.fragment,e),this.h()},h(){document.title="Häufige Fragen (FAQ) | Bauunternehmen Roger",p(t,"name","description"),p(t,"content","Antworten auf häufige Fragen zu Kosten, Dauer, Garantie und Ablauf bei Bauunternehmen Roger."),i.a=o,p(n,"class","section")},m(e,a){d(document.head,t),i.m(b,document.head),d(document.head,o),u(e,l,a),u(e,n,a),u(e,c,a),B(s,e,a),m=!0},p:$,i(e){m||(T(s.$$.fragment,e),m=!0)},o(e){S(s.$$.fragment,e),m=!1},d(e){e&&(i.d(),r(l),r(n),r(c)),r(t),r(o),H(s,e)}}}class k extends v{constructor(t){super(),A(this,t,null,z,F,{})}}export{k as component};
